import * as React from "react";

const IconModalClose = (props: any) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="12"
    height="12"
    fill="none"
    viewBox="0 0 12 12"
  >
    <g clipPath="url(#clip0_717_6)">
      <path
        fill="#365D7E"
        d="m7.026 6.009 4.361-4.361A.725.725 0 1 0 10.361.622L6 4.982 1.639.623A.725.725 0 1 0 .613 1.648l4.36 4.36-4.36 4.362a.725.725 0 1 0 1.026 1.026l4.36-4.361 4.362 4.361a.724.724 0 0 0 1.026 0 .725.725 0 0 0 0-1.026z"
      ></path>
    </g>
    <defs>
      <clipPath id="clip0_717_6">
        <path fill="#fff" d="M.4.4h11.2v11.2H.4z"></path>
      </clipPath>
    </defs>
  </svg>
);

export default IconModalClose;

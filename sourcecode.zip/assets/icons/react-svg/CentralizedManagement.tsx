const CentralizedManagement = () => (
    <svg width="14" height="16" viewBox="0 0 14 19" fill="none" xmlns="http://www.w3.org/2000/svg">
    <path d="M13 17.4382V7.43823M7 17.4382V1.43823M1 17.4382V11.4382" stroke="#382C83" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
    </svg>    
);

export default CentralizedManagement;

import * as React from "react";

const Time = (props: React.SVGProps<SVGSVGElement>) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="20"
    height="20"
    fill="none"
    viewBox="0 0 20 20"
  >
    <g fill="#1C1C1C" clipPath="url(#clip0_2_5513)">
      <path d="M10 .832a9.167 9.167 0 1 0 9.166 9.167A9.177 9.177 0 0 0 10 .832m0 16.667a7.5 7.5 0 1 1 7.5-7.5 7.51 7.51 0 0 1-7.5 7.5"></path>
      <path d="M10.834 9.656V5.001a.833.833 0 1 0-1.667 0v5c0 .221.088.433.244.59l2.5 2.5a.833.833 0 0 0 1.178-1.179z"></path>
    </g>
    <defs>
      <clipPath id="clip0_2_5513">
        <path fill="#fff" d="M0 0h20v20H0z"></path>
      </clipPath>
    </defs>
  </svg>
);

export default Time;

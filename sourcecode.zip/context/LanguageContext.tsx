// src/context/LanguageContext.tsx
import React, { createContext, useState, useContext, useEffect } from "react";
import en from "../locales/en.json";
import bn from "../locales/bn.json";
import ar from "../locales/ar.json";
import { getUserDetailsByUserId } from "../app/common/api-services/adminPanelApi";
import useJwtToken from "../app/config/auth/useJwtToken";

// Define a type for our translations
type TranslationsType = {
    en: typeof en;
    bn: typeof bn;
    ar: typeof ar;
};

const translations: TranslationsType = { en, bn, ar };

type Language = keyof TranslationsType; // Ensures language is one of "en" or "bn"

type LanguageContextType = {
    language: Language | undefined; // Allow language to be undefined initially
    setLanguage: (lang: Language) => void;
    t: (key: keyof typeof en, vars?: Record<string, string | number>) => string;
    // t: (key: keyof typeof en) => string; // Adjust this if keys vary across languages
    // t: (key: keyof typeof en, vars?: Record<string, string | number>) => string;
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC = ({ children }) => {
    const userInfo = useJwtToken();
    const [language, setLanguage] = useState<Language | undefined>(undefined); // Initialize as undefind
    
    // Fetch user language preference when the component mounts
    // const t = (key: keyof typeof en) => {
    //     // Use default "en" translations as a fallback if language is undefined
    //     const selectedLanguage = language && translations[language] ? language : "en";
    //     return (translations[selectedLanguage] as Record<string, string>)[key] || key;
    // };


    const t = (key: keyof typeof en, vars?: Record<string, string | number>): string => {
        const selectedLanguage = language && translations[language] ? language : "en";
        const translationObject = translations[selectedLanguage];
         
        // Resolve dot notation keys like 'issues_list.audio_issues'
        const resolveKey = (obj: any, path: string): string => {
            return path.split('.').reduce((acc, part) => {
                return acc && acc[part] !== undefined ? acc[part] : undefined;
            }, obj) ?? path; // fallback to key if not found
        };

        let text = resolveKey(translationObject, key);
        
        // let text = (translations[selectedLanguage] as Record<string, string>)[key] || key;

        if (!vars) return text;        
        
        // Replace all {{variable}} placeholders
        Object.entries(vars).forEach(([k, v]) => {
            const regex = new RegExp(`{{\\s*${k}\\s*}}`, "g");
            text = text.replace(regex, String(v));
        });

        // Optional plural helper: {{plural:word:countKey}}
        // Example: "You have {{count}} {{plural:item:count}}"
        text = text.replace(/{{\s*plural:(\w+):(\w+)\s*}}/g, (_, word, countKey) => {
            const count = Number(vars[countKey]);
            if (isNaN(count)) return word; // fallback
            return count === 1 ? word : `${word}s`;
        });
        
        return text;
    };

    useEffect(() => {
        const fetchLanguage = async () => {
            if (userInfo?.user.ID) {
                try {
                    const res = await getUserDetailsByUserId(userInfo.user.ID);
                    const userLanguage = res.data.language.toLowerCase();
                    if (userLanguage === "en" || userLanguage === "bn" || userLanguage === "ar") {
                        setLanguage(userLanguage);
                    } else {
                        setLanguage("en"); // Fallback
                    }
                } catch (error) {

                    setLanguage("en"); // Fallback
                }
            } else {
                setLanguage("en"); // Fallback if no userInfo
            }
        };
    
        fetchLanguage();
    }, [userInfo?.user.ID]);
    

    // const t = (key: keyof typeof en) => {
    //     // Return translation based on current language, or fallback to key if undefined
    //     return language ? (translations[language] as Record<string, string>)[key] || key : key;
    // };

    // Render nothing or a loading indicator until the language is fetched
    if (language === undefined) {
        return null; // Or you can return a loading spinner here
    }

    return (
        <LanguageContext.Provider value={{ language, setLanguage, t }}>
            {children}
        </LanguageContext.Provider>
    );
};

export const useLanguage = (): LanguageContextType => {
    const context = useContext(LanguageContext);
    if (!context) throw new Error("useLanguage must be used within a LanguageProvider");
    return context;
};
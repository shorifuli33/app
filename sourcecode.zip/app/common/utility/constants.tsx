export const USER_FEATURES = {
    CHAT : 'chat',
    TRANSCRIPTION:'transcription',
    DESKTOP_APP:'desktopapp',
    CLOUD_RECORDING:'cloudrecording',
}